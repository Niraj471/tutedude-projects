import React from "react";
import "./style1.css";

function Footer() {
  return (
    <footer className="footer">
      <p>Copyright @ 2023</p>
    </footer>
  );
}

export default Footer;
